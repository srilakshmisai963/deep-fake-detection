import { useState } from "react";
import "./App.css";
import logo from "./assets/deepfake_logo.png";

function App() {
  const [videoFile, setVideoFile] = useState(null);
  const [videoURL, setVideoURL] = useState(null);
  const [steps, setSteps] = useState([]);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    setVideoFile(file);
    setVideoURL(URL.createObjectURL(file));
    setSteps([]);
    setResult(null);
    setError(null);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSteps([]);
    setResult(null);
    setError(null);
    setLoading(true);

    const formData = new FormData();
    formData.append("file", videoFile);

    try {
      const response = await fetch("http://127.0.0.1:5000/predict", {
        method: "POST",
        body: formData,
      });

      if (!response.body || !response.ok) {
        throw new Error("Failed to connect to prediction stream.");
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder("utf-8");

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value);
        const lines = chunk.split("\n").filter((line) => line.startsWith("data: "));

        for (const line of lines) {
          const msg = line.replace("data: ", "").trim();
          setSteps((prev) => [...prev, msg]);

          if (msg.startsWith("Done:")) {
            const [label, confidencePart] = msg.replace("Done:", "").trim().split(" (");
            const confidence = confidencePart?.replace("%)", "");
            setResult({ label: label.trim(), confidence });
          }

          if (msg.startsWith("Error:")) {
            setError(msg);
          }
        }
      }
    } catch (err) {
      setError("Error connecting to backend.");
    }

    setLoading(false);
  };

  return (
    <div className="app-wrapper">
      <div className="container">
        <div className="branding">
          <img src={logo} alt="DeepDefender Logo" className="logo" />
          <h1 className="title">DeepDefender (Fusion Model)</h1>
          <p className="subtitle">Real-time Deepfake Detection Using BILSTM + Swin</p>
        </div>

        <form className="form" onSubmit={handleSubmit}>
          <input type="file" accept="video/mp4" className="input-box" onChange={handleFileChange} required />
          <button type="submit" className="button" disabled={loading}>
            {loading ? "Analyzing with Fusion Model..." : videoFile ? "🧠 Detect Deepfake (Fusion)" : "📁 Upload a Video"}
          </button>
        </form>

        {loading && <div className="spinner"></div>}

        {steps.length > 0 && (
          <div className="steps">
            {steps.map((step, idx) => (
              <div key={idx} className="step">✔️ {step}</div>
            ))}
          </div>
        )}

        {videoURL && result && (
          <div className="video-container">
            <div className={`overlay-label ${result.label === "FAKE" ? "fake" : "real"}`}>{result.label} ({result.confidence}%)</div>
            <video src={videoURL} controls className="result-video" />
          </div>
        )}

        {error && <div className="error">{error}</div>}
      </div>
    </div>
  );
}

export default App;
