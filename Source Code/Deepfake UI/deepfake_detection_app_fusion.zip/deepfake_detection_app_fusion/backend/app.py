import os
import tempfile
import shutil
from flask import Flask, request, jsonify, Response, stream_with_context
from flask_cors import CORS
from werkzeug.utils import secure_filename
import time
import queue
import threading

# Import the fusion model
from late_fusion import DeepfakeFusionDetector

# === Flask App ===
app = Flask(__name__)
CORS(app)

@app.route('/predict', methods=['POST'])
def predict():
    def generate():
        if 'file' not in request.files:
            yield "data: Error: No file part in the request\n\n"
            return

        video_file = request.files['file']
        if video_file.filename == '':
            yield "data: Error: No file selected\n\n"
            return

        temp_dir = tempfile.mkdtemp()
        filename = secure_filename(video_file.filename)
        video_path = os.path.join(temp_dir, filename)
        video_file.save(video_path)

        # Create a queue for progress updates
        progress_queue = queue.Queue()
        
        # Function to run the prediction in a separate thread
        def run_prediction():
            try:
                # Initialize the fusion detector
                fusion_detector = DeepfakeFusionDetector()
                
                # Run Swin Transformer
                progress_queue.put("Running Swin Transformer prediction...")
                swin_label, swin_prob, swin_conf = fusion_detector.run_swin_pipeline(video_path)
                
                # Run BiLSTM
                progress_queue.put("Running BILSTM prediction...")
                bilstm_label, bilstm_prob, bilstm_conf = fusion_detector.run_bilstm_pipeline(video_path)
                
                # Fuse results
                progress_queue.put("Fusing results...")
                
                # Calculate fusion without calling predict() again
                if swin_label is None or bilstm_label is None:
                    if swin_label is None and bilstm_label is not None:
                        result = (bilstm_label, bilstm_prob, bilstm_conf)
                    elif bilstm_label is None and swin_label is not None:
                        result = (swin_label, swin_prob, swin_conf)
                    else:
                        result = ("Unknown", 0.5, 0)
                else:
                    # Fuse predictions
                    bilstm_weight = fusion_detector.bilstm_weight
                    swin_weight = fusion_detector.swin_weight
                    
                    fused_prob = (bilstm_weight * bilstm_prob) + (swin_weight * swin_prob)
                    final_label = "FAKE" if fused_prob > 0.5 else "REAL"
                    final_confidence = fused_prob if final_label == "FAKE" else (1 - fused_prob)
                    
                    result = (final_label, fused_prob, final_confidence)
                
                # Put the final result in the queue
                progress_queue.put(f"Done: {result[0]} ({round(result[2] * 100, 2)}%)")
                progress_queue.put(None)  # Signal we're done
                
                # Cleanup
                try:
                    fusion_detector.cleanup()
                except:
                    pass
                    
            except Exception as e:
                progress_queue.put(f"Error: {str(e)}")
                progress_queue.put(None)  # Signal we're done
            finally:
                # Clean up temp directory in this thread
                try:
                    shutil.rmtree(temp_dir, ignore_errors=True)
                except:
                    pass
        
        # Start the prediction thread
        threading.Thread(target=run_prediction).start()
        
        # Stream updates from the queue
        while True:
            message = progress_queue.get()
            if message is None:  # End signal
                break
            yield f"data: {message}\n\n"

    return Response(stream_with_context(generate()), mimetype='text/event-stream')

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(debug=True, port=port)