import os
import subprocess
import pandas as pd
import tempfile
from pathlib import Path

# Paths configuration
OPENSMILE_PATH = "D:/opensmile-3.0-win-x64/bin/SMILExtract.exe"
OPENFACE_PATH = "D:/OpenFace_2.2.0_win_x64/FeatureExtraction.exe"
MFCC_CONFIG = "D:/opensmile-3.0-win-x64/config/mfcc/MFCC12_0_D_A.conf"
OUTPUT_DIR = "F:\Dataset\Custom Videos\misc1"  # Define the output directory
TEMP_DIR = tempfile.mkdtemp()  # Temporary directory for extracted files

def convert_mp4_to_wav(mp4_path, wav_path):
    """
    Convert MP4 file to WAV format using ffmpeg.
    """
    os.makedirs(os.path.dirname(wav_path), exist_ok=True)
    
    # Using ffmpeg to extract audio from video and convert to WAV
    command = [
        "ffmpeg",
        "-i", mp4_path,
        "-q:a", "0",  # Best quality
        "-map", "a",  # Extract audio only
        "-ac", "1",   # Convert to mono
        "-ar", "16000",  # 16kHz sample rate
        wav_path,
        "-y"  # Overwrite existing file
    ]
    
    try:
        subprocess.run(command, check=True, capture_output=True, text=True)
        return True
    except subprocess.CalledProcessError as e:
        print(f"Error converting {mp4_path} to WAV: {e.stdout}")
        print(e.stderr)
        return False

def extract_mfcc_features(wav_path, output_file):
    """
    Extract MFCC features from WAV file using OpenSmile.
    """
    # Ensure output directory exists
    os.makedirs(os.path.dirname(output_file), exist_ok=True)
    
    # Add parameters for frame-level extraction
    command = [
        OPENSMILE_PATH,
        "-C", MFCC_CONFIG,
        "-I", wav_path,
        "-csvoutput", output_file,
        "-appendcsv", "0",            # Don't append to existing file
        "-timestampcsv", "1",         # Include timestamps
        "-headercsvLLD", "1",         # Include headers for LLD features
        "-lldcsvoutput", output_file  # Output LLD (Low-Level Descriptors) features
    ]
    
    try:
        subprocess.run(command, check=True, capture_output=True, text=True)
        
        # Parse the CSV directly to fix any formatting issues
        restructured_csv = restructure_csv(output_file)
        return restructured_csv
    except subprocess.CalledProcessError as e:
        print(f"Error processing {wav_path}: {e.stdout}")
        print(e.stderr)
        return None

def restructure_csv(input_file):
    """
    Restructure a CSV file where rows might not be properly separated by delimiters.
    Handles both semicolon and comma separated files.
    """
    try:
        # Try reading with both delimiters
        try:
            # First try with semicolon
            df = pd.read_csv(input_file, sep=';', encoding='utf-8')
        except:
            # If fails, try with comma
            try:
                df = pd.read_csv(input_file, sep=',', encoding='utf-8')
            except:
                # If both fail, use the manual splitting approach
                return restructure_csv_with_manual_split(input_file, input_file)
        
        # Check if we need to skip the first row (metadata)
        if df.shape[1] == 1 and ';' in df.iloc[0, 0]:
            # If the first row contains semicolons, reread skipping the first row
            df = pd.read_csv(input_file, sep=';', encoding='utf-8', skiprows=1)
        
        # Rename timestamp column if present
        time_columns = [col for col in df.columns if 'time' in col.lower()]
        if time_columns:
            df = df.rename(columns={time_columns[0]: 'frameTime'})
        
        # Add MFCC prefix to all columns except time
        renamed_columns = {}
        for col in df.columns:
            if col != 'frameTime':
                renamed_columns[col] = f"MFCC_{col}"
        
        df = df.rename(columns=renamed_columns)
        
        # Ensure frameTime exists, if not create it
        if 'frameTime' not in df.columns:
            df['frameTime'] = [i * 0.01 for i in range(len(df))]
        
        # Save the restructured file back
        df.to_csv(input_file, index=False)
        return input_file
    except Exception as e:
        print(f"Error restructuring CSV {input_file}: {e}")
        return input_file

def restructure_csv_with_manual_split(input_file, output_file):
    """
    Restructure a CSV file where rows are not properly separated by delimiters.
    Manually splits rows using `;` and saves as a proper CSV.
    """
    try:
        # Open the file and read all lines
        with open(input_file, 'r', encoding='utf-8') as file:
            lines = file.readlines()
        
        # Skip any header comments (lines starting with #)
        while lines and lines[0].startswith('#'):
            lines.pop(0)
        
        # Manually split the rows by semicolon
        data = [line.strip().split(';') for line in lines]
        
        # Ensure consistent number of columns by padding shorter rows
        max_columns = max(len(row) for row in data)
        data = [row + [''] * (max_columns - len(row)) for row in data]
        
        # Create a DataFrame from the manually split data
        if data:
            # Get header from first row if it exists
            headers = data[0]
            if not all(h for h in headers):  # Check if headers are empty
                headers = [f"col_{i}" for i in range(max_columns)]
                df = pd.DataFrame(data, columns=headers)
            else:
                df = pd.DataFrame(data[1:], columns=headers)  # Use first row as headers
            
            # Add frameTime if not present
            if 'frameTime' not in df.columns:
                df['frameTime'] = [i * 0.01 for i in range(len(df))]
            
            # Clean and convert columns to numeric where possible
            for col in df.columns:
                if col != 'frameTime':  # Skip frameTime for now
                    df[col] = pd.to_numeric(df[col], errors='ignore')
                    # Add MFCC prefix if not already present
                    if not col.startswith('MFCC_') and col != 'frameTime':
                        df.rename(columns={col: f"MFCC_{col}"}, inplace=True)
            
            # Ensure directory exists
            os.makedirs(os.path.dirname(output_file), exist_ok=True)
            
            # Save the cleaned DataFrame to a new CSV file
            df.to_csv(output_file, index=False)
            return output_file
        else:
            print(f"No data found in {input_file}")
            return input_file
    except Exception as e:
        print(f"Error manually restructuring CSV {input_file}: {e}")
        return input_file

def extract_facial_features(video_path, output_dir):
    """
    Extracts facial features for a single video using OpenFace.
    """
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    command = [
        OPENFACE_PATH,
        '-f', video_path,
        '-out_dir', output_dir,
        '-aus',  # Extract Action Units
        '-nobadaligned'
    ]
    
    try:
        subprocess.run(command, check=True)
        output_file = os.path.join(output_dir, Path(video_path).stem + '.csv')
        return output_file
    except subprocess.CalledProcessError as e:
        print(f"Error extracting facial features for {video_path}: {e}")
        return None

def filter_au_features(feature_file):
    """
    Filters the extracted features to retain metadata columns and only the regression AU values.
    """
    try:
        df = pd.read_csv(feature_file)
        
        # Get all columns from the DataFrame
        all_columns = df.columns.tolist()
        
        # Identify classification AU columns (those ending with '_c')
        classification_au_cols = [col for col in all_columns if col.endswith('_c')]
        
        # Keep all columns except classification AU columns
        columns_to_keep = [col for col in all_columns if col not in classification_au_cols]
        
        # Create filtered DataFrame
        df = df[columns_to_keep]
        
        # Save back to CSV
        df.to_csv(feature_file, index=False)
        print(f"Filtered {feature_file} to remove classification AUs while keeping metadata")
        return feature_file
    except Exception as e:
        print(f"Error filtering features in {feature_file}: {e}")
        return None

def process_video(video_path, output_dir=None):
    """
    Unified pipeline to process a single video file for both audio and facial features.
    
    Args:
        video_path (str): Path to the MP4 video file
        output_dir (str, optional): Directory to save the output files. 
                                   If None, uses the global OUTPUT_DIR.
    
    Returns:
        tuple: Paths to the output files (audio_csv, facial_csv) or None if processing failed
    """
    # Use specified output directory or default
    output_directory = output_dir if output_dir is not None else OUTPUT_DIR
    os.makedirs(output_directory, exist_ok=True)
    
    print(f"Processing video: {video_path}")
    
    # Create specific subdirectories for each feature type
    audio_output_dir = os.path.join(output_directory, "audio_features")
    facial_output_dir = os.path.join(output_directory, "facial_features")
    
    os.makedirs(audio_output_dir, exist_ok=True)
    os.makedirs(facial_output_dir, exist_ok=True)
    
    # Get the file name without extension
    file_base = os.path.splitext(os.path.basename(video_path))[0]
    
    audio_csv = None
    facial_csv = None
    
    try:
        # 1. Extract Audio Features
        print("Extracting audio MFCC features...")
        temp_wav_path = os.path.join(TEMP_DIR, f"{file_base}.wav")
        audio_output_csv = os.path.join(audio_output_dir, f"{file_base}_MFCC.csv")
        
        if not os.path.exists(audio_output_csv):
            if convert_mp4_to_wav(video_path, temp_wav_path):
                audio_csv = extract_mfcc_features(temp_wav_path, audio_output_csv)
                print(f"Audio features saved to: {audio_csv}")
            else:
                print("Failed to convert video to WAV. Skipping audio feature extraction.")
        else:
            print(f"Audio features already exist at: {audio_output_csv}")
            audio_csv = audio_output_csv
        
        # Clean up temporary WAV file
        if os.path.exists(temp_wav_path):
            os.remove(temp_wav_path)
        
        # 2. Extract Facial Features
        print("Extracting facial features...")
        facial_output_file = extract_facial_features(video_path, facial_output_dir)
        
        if facial_output_file and os.path.exists(facial_output_file):
            facial_csv = filter_au_features(facial_output_file)
            print(f"Facial features saved to: {facial_csv}")
        else:
            print("Failed to extract facial features.")
        
        # Return both CSV paths
        return audio_csv, facial_csv
        
    except Exception as e:
        print(f"Error processing {video_path}: {e}")
        return None, None
    finally:
        # Clean up temporary directory
        try:
            import shutil
            shutil.rmtree(TEMP_DIR)
            print(f"Cleaned up temporary directory: {TEMP_DIR}")
        except Exception as e:
            print(f"Error cleaning up temporary directory: {e}")


import pandas as pd
import numpy as np
import os

def process_single_files(au_file_path, mfcc_file_path, output_dir=None):
    """
    Process a single AU and MFCC file pair, creating a one-to-one mapping between AU timestamps and MFCC data.
    For each AU timestamp, it finds the closest MFCC timestamp, ensuring the output has exactly
    the same number of rows as the AU file.
   
    Parameters:
    -----------
    au_file_path : str or pandas.DataFrame
        Path to the AU CSV file or the AU data DataFrame
    mfcc_file_path : str or pandas.DataFrame
        Path to the MFCC CSV file or the MFCC data DataFrame
    output_dir : str, optional
        Directory to save the aligned MFCC file. If None, will use the same directory and filename as the MFCC file.
    
    Returns:
    --------
    pandas.DataFrame
        The aligned MFCC data
    """
    # Determine if inputs are file paths or DataFrames
    if isinstance(au_file_path, str):
        print(f"Processing AU file: {au_file_path}")
        au_data = pd.read_csv(au_file_path)
    else:
        print("Processing AU data from DataFrame")
        au_data = au_file_path
    
    if isinstance(mfcc_file_path, str):
        print(f"Using MFCC file: {mfcc_file_path}")
        mfcc_data = pd.read_csv(mfcc_file_path)
        original_mfcc_path = mfcc_file_path
    else:
        print("Using MFCC data from DataFrame")
        mfcc_data = mfcc_file_path
        original_mfcc_path = None
    
    # Determine output file path
    if output_dir is not None:
        # If output_dir is specified, use it with the original MFCC filename
        if original_mfcc_path:
            mfcc_filename = os.path.basename(original_mfcc_path)
            output_file_path = os.path.join(output_dir, mfcc_filename)
        else:
            # If MFCC is a DataFrame and output_dir is specified, use a timestamp
            output_file_path = os.path.join(output_dir, f"aligned_mfcc_{pd.Timestamp.now().strftime('%Y%m%d_%H%M%S')}.csv")
    else:
        # If no output_dir is specified, use the original MFCC path
        if original_mfcc_path:
            output_file_path = original_mfcc_path
        else:
            # If MFCC is a DataFrame and no output_dir, use current directory
            output_file_path = os.path.join(os.getcwd(), f"aligned_mfcc_{pd.Timestamp.now().strftime('%Y%m%d_%H%M%S')}.csv")
    
    print(f"Output will be saved to: {output_file_path}")
   
    # Clean up column names for AU data (strip whitespace)
    au_data.columns = au_data.columns.str.strip()
   
    # Get AU timestamps
    au_timestamps = au_data['timestamp'].values
    mfcc_timestamps = mfcc_data['frameTime'].values
   
    # Create a new MFCC dataframe with the same number of rows as AU file
    aligned_mfcc_data = pd.DataFrame(columns=mfcc_data.columns)
   
    # For each AU timestamp, find the closest MFCC timestamp
    for au_time in au_timestamps:
        # Calculate absolute time differences
        time_diffs = np.abs(mfcc_timestamps - au_time)
       
        # Find the index of the closest MFCC timestamp
        closest_idx = np.argmin(time_diffs)
       
        # Add this row to the aligned MFCC data
        aligned_mfcc_data = pd.concat([aligned_mfcc_data, mfcc_data.iloc[[closest_idx]]], ignore_index=True)
   
    # Print statistics for verification
    print(f"AU file rows: {len(au_data)}")
    print(f"Aligned MFCC rows: {len(aligned_mfcc_data)}")
   
    # Save the aligned MFCC data to the output file
    aligned_mfcc_data.to_csv(output_file_path, index=False)
    print(f"Aligned MFCC data saved to: {output_file_path}")
    
    return output_file_path

# Example usage with variable paths:
# facial_csv and audio_csv can be either file paths or DataFrames
# Option 1: If facial_csv and audio_csv are file paths:


# Option 2: If facial_csv and audio_csv are DataFrames but you know the original MFCC file path:
# aligned_data = process_single_files(facial_csv, audio_csv, output_dir=os.path.dirname("F:/Dataset/Custom Videos/misc1/audio_features/00092_MFCC.csv"))
import os
import pandas as pd

def process_facial_features(facial_csv, output_path=None):
    """
    Process facial features CSV file to filter frames.
    
    Args:
        facial_csv (str): Path to facial features CSV file
        output_path (str, optional): Path to save processed CSV. If None, returns DataFrame
    
    Returns:
        str or pd.DataFrame: Path to saved CSV if output_path is provided, else the processed DataFrame
    """
    # Read the CSV file
    data = pd.read_csv(facial_csv)
    
    # Fix column names if necessary
    data.columns = [col.strip() for col in data.columns]
    
    # Ensure the column name is correct
    if 'timestamp' not in data.columns:
        raise ValueError(f"Column 'timestamp' not found in {facial_csv}, available columns: {data.columns}")
    
    # Extract second and frame information
    data['second'] = data['timestamp'].astype(int)
    data['frame_within_second'] = (data['timestamp'] * 10).astype(int) % 10
    
    # Filter to keep only 10 frames per second
    filtered_data = data.drop_duplicates(subset=['second', 'frame_within_second'])
    
    if output_path:
        # Create output directory if it doesn't exist
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        # Save the filtered data
        filtered_data.to_csv(output_path, index=False)
        return output_path
    else:
        return filtered_data

def process_audio_features(audio_csv, output_path=None):
    """
    Process audio features CSV file to filter frames.
    
    Args:
        audio_csv (str): Path to audio features CSV file
        output_path (str, optional): Path to save processed CSV. If None, returns DataFrame
    
    Returns:
        str or pd.DataFrame: Path to saved CSV if output_path is provided, else the processed DataFrame
    """
    # Read the CSV file
    data = pd.read_csv(audio_csv)
    
    # Fix column names if necessary
    data.columns = [col.strip() for col in data.columns]
    
    # Ensure the column name is correct
    if 'frameTime' not in data.columns:
        raise ValueError(f"Column 'frameTime' not found in {audio_csv}, available columns: {data.columns}")
    
    # Extract second and frame information
    data['second'] = data['frameTime'].astype(int)
    data['frame_within_second'] = (data['frameTime'] * 10).astype(int) % 10
    
    # Filter to keep only 10 frames per second
    filtered_data = data.drop_duplicates(subset=['second', 'frame_within_second'])
    
    if output_path:
        # Create output directory if it doesn't exist
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        # Save the filtered data
        filtered_data.to_csv(output_path, index=False)
        return output_path
    else:
        return filtered_data

def process_multimodal_features(aligned_data, facial_csv, output_dir=None):
    """
    Process both audio and facial features and return paths to processed files.
    
    Args:
        aligned_data (str): Path to audio features CSV file
        facial_csv (str): Path to facial features CSV file
        output_dir (str, optional): Directory to save processed files. If None, uses same directory as input
    
    Returns:
        dict: Dictionary containing paths to processed files
    """
    # Generate output paths
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)
        audio_output = os.path.join(output_dir, os.path.basename(aligned_data).replace('.csv', '_filtered.csv'))
        facial_output = os.path.join(output_dir, os.path.basename(facial_csv).replace('.csv', '_filtered.csv'))
    else:
        audio_output = aligned_data.replace('.csv', '_filtered.csv')
        facial_output = facial_csv.replace('.csv', '_filtered.csv')
    
    # Process files
    processed_audio_path = process_audio_features(aligned_data, audio_output)
    processed_facial_path = process_facial_features(facial_csv, facial_output)
    
    return {
        'processed_audio_path': processed_audio_path,
        'processed_facial_path': processed_facial_path
    }

import os
import pandas as pd
import numpy as np
from tensorflow.keras.models import load_model
from sklearn.preprocessing import StandardScaler

def predict_for_single_file(processed_facial_path, model_path_valence, model_path_arousal, output_path=None, sequence_length=30, step_size=1):
    """
    Process a single file and predict valence and arousal values
    
    Args:
        processed_facial_path: Path to the facial features CSV file
        model_path_valence: Path to the valence model
        model_path_arousal: Path to the arousal model
        output_path: Path to save the output CSV (optional)
        sequence_length: Length of sequence for prediction
        step_size: Step size for sliding window
        
    Returns:
        DataFrame with original data and predicted valence and arousal values
        Output file path if saved
    """
    # Load models
    model_valence = load_model(model_path_valence)
    model_arousal = load_model(model_path_arousal)
    
    # Load facial data
    if os.path.exists(processed_facial_path):
        data = pd.read_csv(processed_facial_path)
        
        # Extract Action Units columns
        au_cols = [col for col in data.columns if 'AU' in col][:17]
        
        # Check if we have enough data
        if len(data) < sequence_length:
            print(f"File has fewer rows ({len(data)}) than the required sequence length ({sequence_length}).")
            return None, None
        
        # Standardize features
        scaler = StandardScaler()
        features = scaler.fit_transform(data[au_cols])
        
        # Initialize arrays for predictions
        valence_predictions = np.zeros(len(features))
        arousal_predictions = np.zeros(len(features))
        counts = np.zeros(len(features))
        
        # Slide window through the data
        for start in range(0, len(features) - sequence_length + 1, step_size):
            end = start + sequence_length
            sequence = features[start:end].reshape(1, sequence_length, 17)
            
            valence_pred = model_valence.predict(sequence, verbose=0)
            arousal_pred = model_arousal.predict(sequence, verbose=0)
            
            valence_predictions[start:end] += valence_pred.flatten()
            arousal_predictions[start:end] += arousal_pred.flatten()
            counts[start:end] += 1
        
        # Average predictions for frames that were in multiple windows
        valence_predictions[counts > 0] /= counts[counts > 0]
        arousal_predictions[counts > 0] /= counts[counts > 0]
        
        # Add predictions to the original data
        data['predicted_valence'] = valence_predictions
        data['predicted_arousal'] = arousal_predictions
        
        # Save to output file if path is provided
        if output_path:
            # Create directories if they don't exist
            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            data.to_csv(output_path, index=False)
            print(f"Predictions saved to {output_path}")
            
        return data, output_path
    else:
        print(f"File {processed_facial_path} not found.")
        return None, None



import os
import pandas as pd
import numpy as np
from tensorflow.keras.models import load_model
from sklearn.preprocessing import StandardScaler

def predict_for_single_audio_file(processed_audio_path, model_path_valence, model_path_arousal, 
                                  scaler_path_valence, scaler_path_arousal, 
                                  output_path=None, sequence_length=30, step_size=1):
    """
    Process a single audio file and predict valence and arousal values
    
    Args:
        processed_audio_path: Path to the audio features CSV file (MFCC features)
        model_path_valence: Path to the valence model
        model_path_arousal: Path to the arousal model
        scaler_path_valence: Path to the saved valence scaler parameters
        scaler_path_arousal: Path to the saved arousal scaler parameters
        output_path: Path to save the output CSV (optional)
        sequence_length: Length of sequence for prediction
        step_size: Step size for sliding window
        
    Returns:
        DataFrame with original data and predicted valence and arousal values
        Output file path if saved
    """
    # Load models
    model_valence = load_model(model_path_valence)
    model_arousal = load_model(model_path_arousal)
    
    # Load the scalers used during training
    valence_scaler_params = np.load(scaler_path_valence, allow_pickle=True)
    arousal_scaler_params = np.load(scaler_path_arousal, allow_pickle=True)
    
    # Create scalers with the saved parameters
    scaler_valence = StandardScaler()
    scaler_valence.mean_ = valence_scaler_params[0]
    scaler_valence.scale_ = valence_scaler_params[1]
    
    scaler_arousal = StandardScaler()
    scaler_arousal.mean_ = arousal_scaler_params[0]
    scaler_arousal.scale_ = arousal_scaler_params[1]
    
    # Load audio data
    if os.path.exists(processed_audio_path):
        data = pd.read_csv(processed_audio_path)
        
        # Remove MFCC_name column if it exists
        if 'MFCC_name' in data.columns:
            data = data.drop(columns=['MFCC_name'])
        
        # Extract MFCC features
        mfcc_cols = [col for col in data.columns if 'MFCC' in col]
        
        # Check if we have the expected number of MFCC features
        if len(mfcc_cols) != 39:
            print(f"File has {len(mfcc_cols)} MFCC features instead of 39. Processing may be affected.")
        
        # Check if we have enough data
        if len(data) < sequence_length:
            print(f"File has fewer rows ({len(data)}) than the required sequence length ({sequence_length}).")
            return None, None
        
        # Normalize MFCC features using the saved scalers
        features_valence = scaler_valence.transform(data[mfcc_cols])
        features_arousal = scaler_arousal.transform(data[mfcc_cols])
        
        # Initialize arrays for predictions
        valence_predictions = np.zeros(len(features_valence))
        arousal_predictions = np.zeros(len(features_valence))
        counts = np.zeros(len(features_valence))
        
        # Slide window through the data
        for start in range(0, len(features_valence) - sequence_length + 1, step_size):
            end = start + sequence_length
            # Reshape for LSTM input (samples, time steps, features)
            sequence_valence = features_valence[start:end].reshape(1, sequence_length, len(mfcc_cols))
            sequence_arousal = features_arousal[start:end].reshape(1, sequence_length, len(mfcc_cols))
            
            # Make predictions without verbose output
            valence_pred = model_valence.predict(sequence_valence, verbose=0)
            arousal_pred = model_arousal.predict(sequence_arousal, verbose=0)
            
            # Accumulate predictions
            valence_predictions[start:end] += valence_pred.flatten()
            arousal_predictions[start:end] += arousal_pred.flatten()
            counts[start:end] += 1
        
        # Average predictions for frames that were in multiple windows
        valence_predictions[counts > 0] /= counts[counts > 0]
        arousal_predictions[counts > 0] /= counts[counts > 0]
        
        # Add predictions to the original data
        data['predicted_valence'] = valence_predictions
        data['predicted_arousal'] = arousal_predictions
        
        # Save to output file if path is provided
        if output_path:
            # Create directories if they don't exist
            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            data.to_csv(output_path, index=False)
            print(f"Predictions saved to {output_path}")
            
        return data, output_path
    else:
        print(f"File {processed_audio_path} not found.")
        return None, None


        # Paths configuration
import os
import pickle
import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.preprocessing import StandardScaler

def predict_single_video(saved_model_path, saved_scaler_path, saved_path_speech, saved_path_facial, max_seq_length=100):
    """
    Predict whether a single video is real or fake using the saved model.
    
    Args:
        saved_model_path: Path to the saved model
        saved_scaler_path: Path to the saved scaler
        saved_path_speech: Path to the speech CSV file with valence-arousal data
        saved_path_facial: Path to the facial CSV file with valence-arousal data
        max_seq_length: Maximum sequence length expected by the model
    
    Returns:
        prediction: "REAL" or "FAKE"
        confidence: Confidence score (probability)
    """
    # Load the model
    print(f"Loading model from {saved_model_path}...")
    model = tf.keras.models.load_model(saved_model_path)
    
    # Load the scaler
    print(f"Loading scaler from {saved_scaler_path}...")
    with open(saved_scaler_path, 'rb') as f:
        scaler = pickle.load(f)
    
    # Check if the CSV files exist
    if not os.path.exists(saved_path_speech):
        raise FileNotFoundError(f"Speech CSV file not found: {saved_path_speech}")
    
    if not os.path.exists(saved_path_facial):
        raise FileNotFoundError(f"Facial CSV file not found: {saved_path_facial}")
    
    # Load the CSV files
    print("Loading speech and facial data...")
    try:
        speech_df = pd.read_csv(saved_path_speech)
        facial_df = pd.read_csv(saved_path_facial)
    except Exception as e:
        raise Exception(f"Error loading CSV files: {e}")
    
    # Check if both dataframes have data
    if len(speech_df) == 0 or len(facial_df) == 0:
        raise ValueError("One or both CSV files are empty")
    
    # Make sure we have the same number of frames
    min_frames = min(len(speech_df), len(facial_df))
    speech_df = speech_df.iloc[:min_frames]
    facial_df = facial_df.iloc[:min_frames]
    
    # Extract valence and arousal values from both sources
    speech_va = speech_df[['predicted_valence', 'predicted_arousal']].values
    facial_va = facial_df[['predicted_valence', 'predicted_arousal']].values
    
    # Combine the features (4 features: speech_valence, speech_arousal, facial_valence, facial_arousal)
    combined_features = np.hstack((speech_va, facial_va))
    
    # Pad/truncate sequence to max_seq_length
    if len(combined_features) > max_seq_length:
        # Truncate
        sequence = combined_features[:max_seq_length]
    else:
        # Pad with zeros
        padded_seq = np.zeros((max_seq_length, 4))  # 4 features
        padded_seq[:len(combined_features)] = combined_features
        sequence = padded_seq
    
    # Reshape for model input (add batch dimension)
    X = np.expand_dims(sequence, axis=0)
    
    # Normalize the data
    X_reshaped = X.reshape(-1, X.shape[-1])
    X_scaled = scaler.transform(X_reshaped)
    X = X_scaled.reshape(X.shape)
    
    # Make prediction
    print("Making prediction...")
    prediction_prob = model.predict(X)[0][0]
    
    # Convert probability to class label
    prediction_label = "FAKE" if prediction_prob > 0.5 else "REAL"
    
    # Calculate confidence
    confidence = prediction_prob if prediction_prob > 0.5 else 1 - prediction_prob
    
    return prediction_label, prediction_prob, confidence

def main():
    # Define paths
    saved_model_path = 'deepfake_detection_combined_audio_video_bilstm.keras'
    saved_scaler_path = 'combined_audio_video_scaler.pkl'
    
    
    # If you want to use command line arguments instead, uncomment the following:
    """
    import argparse
    parser = argparse.ArgumentParser(description='Predict single video as real or fake')
    parser.add_argument('--model', required=True, help='Path to saved model')
    parser.add_argument('--scaler', required=True, help='Path to saved scaler')
    parser.add_argument('--speech', required=True, help='Path to speech CSV file')
    parser.add_argument('--facial', required=True, help='Path to facial CSV file')
    args = parser.parse_args()
    
    saved_model_path = args.model
    saved_scaler_path = args.scaler
    saved_path_speech = args.speech
    saved_path_facial = args.facial
    """
    
    try:
        # Get prediction
        prediction, raw_score, confidence = predict_single_video(
            saved_model_path, 
            saved_scaler_path, 
            saved_path_speech, 
            saved_path_facial
        )
        
        # Print results
        print("\n" + "="*40)
        print(f"Prediction: {prediction}")
        print(f"Raw Score: {raw_score:.4f}")
        print(f"Confidence: {confidence:.2%}")
        print("="*40)
        
        return prediction, raw_score, confidence
        
    except Exception as e:
        print(f"Error during prediction: {e}")
        return None, None, None

if __name__ == "__main__":
    # Example usage for a single video file
    video_path = r"F:\Dataset\Custom Videos\FAKE\trump_elon_fake.mp4"  # Replace with actual video path
    audio_csv, facial_csv = process_video(video_path)
    
    print("\nProcessing Summary:")
    print(f"Input Video: {video_path}")
    print(f"Audio Features CSV: {audio_csv if audio_csv else 'Failed'}")
    print(f"Facial Features CSV: {facial_csv if facial_csv else 'Failed'}")
    aligned_data = process_single_files(facial_csv, audio_csv)
    output_dir = "F:\Dataset\Custom Videos\misc1"
    
    # Process files
    result = process_multimodal_features(aligned_data, facial_csv, output_dir)
    
    # Output paths for further processing
    processed_audio_path = result['processed_audio_path']
    processed_facial_path = result['processed_facial_path']
    
    print(f"Processed audio features saved to: {processed_audio_path}")
    print(f"Processed facial features saved to: {processed_facial_path}")
    # Paths configuration
    model_path_valence = 'D:\\Deepfake phase 2\\sewa\\Valence_best_model.keras'
    model_path_arousal = 'D:\\Deepfake phase 2\\sewa\\Arousal_best_model.keras'

    # Generate output path (optional)
    output_path = processed_facial_path.replace('.csv', '_predictions.csv')

    # Process the file
    result_data, saved_path_facial = predict_for_single_file(
        processed_facial_path,
        model_path_valence,
        model_path_arousal,
        output_path
    )

    # Check if processing was successful
    if result_data is not None:
        print(f"Processing completed. DataFrame shape: {result_data.shape}")
    model_path_valence = 'D:\\Deepfake phase 2\\sewa\\Valence_mfcc_best_model.keras'
    model_path_arousal = 'D:\\Deepfake phase 2\\sewa\\Arousal_mfcc_best_model.keras'
            
            # Paths to saved scalers
    scaler_path_valence = 'D:\\Deepfake phase 2\\sewa\\valence_mfcc_scaler.npy'
    scaler_path_arousal = 'D:\\Deepfake phase 2\\sewa\\arousal_mfcc_scaler.npy'
            
            # Generate output path (optional)
    output_path = processed_audio_path.replace('.csv', '_predictions.csv')
            
            # Process the file
    result_data, saved_path_speech = predict_for_single_audio_file(
                processed_audio_path,
                model_path_valence,
                model_path_arousal,
                scaler_path_valence,
                scaler_path_arousal,
                output_path
            )

            
            # Check if processing was successful
    if result_data is not None:
        print(f"Processing completed. DataFrame shape: {result_data.shape}")