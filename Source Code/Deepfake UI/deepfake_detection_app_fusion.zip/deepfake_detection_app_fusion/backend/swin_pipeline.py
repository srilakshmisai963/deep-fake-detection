# Necessary imports
import os
import torch
import torch.nn as nn
from tqdm.auto import tqdm
import timm
import cv2
import numpy as np

# Define the Swin Transformer Video Model class
class SwinTransformerVideo(nn.Module):
    def __init__(self, num_classes=2):
        super(SwinTransformerVideo, self).__init__()
        self.swin_transformer = timm.create_model('swin_base_patch4_window7_224', pretrained=False)
        self.swin_transformer.head = nn.Linear(self.swin_transformer.head.in_features, num_classes)
        in_features = self.swin_transformer.head.in_features
        self.swin_transformer.head = nn.Linear(in_features, num_classes)
        # No need to manually replace the head as it's already integrated in the model

    def forward(self, x):
        x = x.view(-1, 3, 224, 224)
        batch_size = x.size(0)
        x = x.view(-1, 3, 224, 224)
        x = self.swin_transformer(x)
        x = x.view(batch_size, -1, 2)
        x = x.mean(dim=1)
        return x

# Function to create a thumbnail from a video
def create_thumbnail(video_path):
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise ValueError(f"Could not open video file: {video_path}")

    frames = []
    for _ in range(4):
        ret, frame = cap.read()
        if not ret:
            break
        frames.append(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))

    cap.release()

    if len(frames) < 4:
        while len(frames) < 4:
            frames.append(frames[-1].copy())

    target_size = (224, 224)
    resized_frames = [cv2.resize(frame, target_size) for frame in frames]
    thumbnail = np.mean(resized_frames, axis=0)

    return torch.tensor(thumbnail).permute(2, 0, 1).float() / 255.0

# Prediction pipeline
def predict_fake_or_real(video_path):
    print("Starting prediction...")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")

    # Load the model
    print("Loading model...")
    model = SwinTransformerVideo(num_classes=2)
    model_path = 'D:/Deepfake phase 2/swin+bi/swin_transformer_video.pth'
    model.load_state_dict(torch.load(model_path, map_location=device), strict=False)
    model.to(device)
    print("Model loaded successfully.")
    model.eval()

    try:
        thumbnail = create_thumbnail(video_path).unsqueeze(0).to(device)
    except Exception as e:
        print(f"Error processing video: {e}")
        return None

    with torch.no_grad():
        progress = tqdm(total=1, desc='Inference Progress', unit='step')
        print("Performing inference...")
        output = model(thumbnail)
        progress.update(1)
        progress.close()
        print("Inference complete.")
        predicted = torch.argmax(output, dim=1)
        label = 'FAKE' if predicted.squeeze().item() == 1 else 'REAL'

    confidence = torch.softmax(output, dim=1)[0][predicted].item()
    print(f"Prediction completed: {label} with confidence: {confidence:.2f}")
    import matplotlib.pyplot as plt
    plt.imshow(thumbnail.squeeze().permute(1, 2, 0).cpu().numpy())
    plt.title(f"Prediction: {label} with confidence: {confidence:.2f}")
    plt.show()
    return label

# Example usage
#video_path = 'F:/Dataset/Custom Videos/FAKE/ashwanth-anirudh-fullfake.mp4'
#predict_fake_or_real(video_path)
