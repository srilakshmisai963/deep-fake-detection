# Fusion Pipeline for Deepfake Detection
# Combining Swin Transformer and BiLSTM models with weighted fusion

import os
import torch
import numpy as np
import pandas as pd
from tqdm.auto import tqdm
import matplotlib.pyplot as plt

# Import functions from existing pipelines
from swin_pipeline import SwinTransformerVideo, create_thumbnail, predict_fake_or_real
from pipeline import (process_video, process_single_files, process_multimodal_features, 
                     predict_for_single_file, predict_for_single_audio_file, predict_single_video)

class DeepfakeFusionDetector:
    def __init__(self, bilstm_weight=0.8, swin_weight=0.2):
        """
        Initialize the fusion detector with specified weights for each model.
        
        Args:
            bilstm_weight (float): Weight for BiLSTM model predictions (0-1)
            swin_weight (float): Weight for Swin model predictions (0-1)
        """
        self.bilstm_weight = bilstm_weight
        self.swin_weight = swin_weight
        
        # Model paths
        self.swin_model_path = 'D:/Deepfake phase 2/swin+bi/swin_transformer_video.pth'
        self.bilstm_model_path = 'deepfake_detection_combined_audio_video_bilstm.keras'
        self.bilstm_scaler_path = 'combined_audio_video_scaler.pkl'
        
        # Feature extraction model paths
        self.facial_model_path_valence = 'D:/Deepfake phase 2/sewa/Valence_best_model.keras'
        self.facial_model_path_arousal = 'D:/Deepfake phase 2/sewa/Arousal_best_model.keras'
        self.audio_model_path_valence = 'D:/Deepfake phase 2/sewa/Valence_mfcc_best_model.keras'
        self.audio_model_path_arousal = 'D:/Deepfake phase 2/sewa/Arousal_mfcc_best_model.keras'
        self.audio_scaler_path_valence = 'D:/Deepfake phase 2/sewa/valence_mfcc_scaler.npy'
        self.audio_scaler_path_arousal = 'D:/Deepfake phase 2/sewa/arousal_mfcc_scaler.npy'
        
        # Temporary directory for processing
        self.output_dir = "temp_processing"
        os.makedirs(self.output_dir, exist_ok=True)
        
        print(f"Initialized Fusion Detector with BiLSTM weight: {bilstm_weight}, Swin weight: {swin_weight}")
    
    def run_swin_pipeline(self, video_path):
        """
        Run the Swin Transformer pipeline on a video.
        
        Args:
            video_path (str): Path to the video file
            
        Returns:
            tuple: (label, probability, confidence)
        """
        print("\n===== Running Swin Transformer Pipeline =====")
        try:
            # Use device with CUDA if available
            device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
            
            # Load the model
            model = SwinTransformerVideo(num_classes=2)
            model.load_state_dict(torch.load(self.swin_model_path, map_location=device), strict=False)
            model.to(device)
            model.eval()
            
            # Create thumbnail from video
            thumbnail = create_thumbnail(video_path).unsqueeze(0).to(device)
            
            # Perform inference
            with torch.no_grad():
                output = model(thumbnail)
                
                # Get prediction
                probabilities = torch.softmax(output, dim=1)
                predicted_class = torch.argmax(output, dim=1).item()
                
                # Extract FAKE probability (class 1)
                fake_prob = probabilities[0][1].item()
                
                # Determine label and confidence
                label = 'FAKE' if predicted_class == 1 else 'REAL'
                confidence = fake_prob if label == 'FAKE' else 1 - fake_prob
            
            print(f"Swin prediction: {label} (Raw score: {fake_prob:.4f}, Confidence: {confidence:.4f})")
            return label, fake_prob, confidence
            
        except Exception as e:
            print(f"Error in Swin pipeline: {e}")
            return None, 0.5, 0  # Default to uncertain prediction on error
    
    def run_bilstm_pipeline(self, video_path):
        """
        Run the BiLSTM pipeline on a video.
        
        Args:
            video_path (str): Path to the video file
            
        Returns:
            tuple: (label, probability, confidence)
        """
        print("\n===== Running BiLSTM Pipeline =====")
        try:
            # Step 1: Extract basic features
            print("Extracting basic features...")
            audio_csv, facial_csv = process_video(video_path, self.output_dir)
            
            if audio_csv is None or facial_csv is None:
                raise ValueError("Feature extraction failed. Check if the video is valid.")
            
            # Step 2: Align audio to facial timeline
            print("Aligning audio features...")
            aligned_data = process_single_files(facial_csv, audio_csv, self.output_dir)
            
            # Step 3: Process multimodal features
            print("Processing multimodal features...")
            result = process_multimodal_features(aligned_data, facial_csv, self.output_dir)
            processed_audio_path = result['processed_audio_path']
            processed_facial_path = result['processed_facial_path']
            
            # Step 4: Predict valence-arousal from facial features
            print("Predicting valence-arousal from facial features...")
            _, saved_path_facial = predict_for_single_file(
                processed_facial_path,
                self.facial_model_path_valence,
                self.facial_model_path_arousal,
                os.path.join(self.output_dir, os.path.basename(processed_facial_path).replace('.csv', '_predictions.csv'))
            )
            
            # Step 5: Predict valence-arousal from audio features
            print("Predicting valence-arousal from audio features...")
            _, saved_path_speech = predict_for_single_audio_file(
                processed_audio_path,
                self.audio_model_path_valence, 
                self.audio_model_path_arousal,
                self.audio_scaler_path_valence,
                self.audio_scaler_path_arousal,
                os.path.join(self.output_dir, os.path.basename(processed_audio_path).replace('.csv', '_predictions.csv'))
            )
            
            # Step 6: Final prediction using BiLSTM
            print("Making final BiLSTM prediction...")
            prediction, raw_score, confidence = predict_single_video(
                self.bilstm_model_path,
                self.bilstm_scaler_path,
                saved_path_speech,
                saved_path_facial
            )
            
            print(f"BiLSTM prediction: {prediction} (Raw score: {raw_score:.4f}, Confidence: {confidence:.4f})")
            return prediction, raw_score, confidence
            
        except Exception as e:
            print(f"Error in BiLSTM pipeline: {e}")
            return None, 0.5, 0  # Default to uncertain prediction on error
    
    def predict(self, video_path, visualize=True):
        """
        Run both models and fuse their predictions.
        
        Args:
            video_path (str): Path to the video file
            visualize (bool): Whether to visualize the results
            
        Returns:
            tuple: (final_label, final_probability, final_confidence)
        """
        print(f"\n==================================================")
        print(f"Processing video: {video_path}")
        print(f"==================================================\n")
        
        # Get predictions from both models
        swin_label, swin_prob, swin_conf = self.run_swin_pipeline(video_path)
        bilstm_label, bilstm_prob, bilstm_conf = self.run_bilstm_pipeline(video_path)
        
        # Handle case where one model fails
        if swin_label is None:
            print("Swin prediction failed. Using only BiLSTM prediction.")
            return bilstm_label, bilstm_prob, bilstm_conf
            
        if bilstm_label is None:
            print("BiLSTM prediction failed. Using only Swin prediction.")
            return swin_label, swin_prob, swin_conf
        
        # Note: BiLSTM returns probability for FAKE class directly
        # Ensure Swin also returns probability for FAKE class
        
        # Fuse predictions with weights
        fused_prob = (self.bilstm_weight * bilstm_prob) + (self.swin_weight * swin_prob)
        
        # Determine final label and confidence
        final_label = "FAKE" if fused_prob > 0.5 else "REAL"
        final_confidence = fused_prob if final_label == "FAKE" else (1 - fused_prob)
        
        # Print results
        print("\n" + "="*50)
        print("FUSION RESULTS:")
        print(f"Swin Transformer: {swin_label} (Probability: {swin_prob:.4f}, Weight: {self.swin_weight})")
        print(f"BiLSTM: {bilstm_label} (Probability: {bilstm_prob:.4f}, Weight: {self.bilstm_weight})")
        print("-"*50)
        print(f"FINAL PREDICTION: {final_label}")
        print(f"Probability: {fused_prob:.4f}")
        print(f"Confidence: {final_confidence:.2%}")
        print("="*50)
        
        # Visualization of the fusion
        if visualize:
            self.visualize_fusion(swin_prob, bilstm_prob, fused_prob, final_label)
        
        return final_label, fused_prob, final_confidence
    
    def visualize_fusion(self, swin_prob, bilstm_prob, fused_prob, final_label):
        """
        Visualize the fusion of predictions.
        
        Args:
            swin_prob (float): Swin model probability of FAKE
            bilstm_prob (float): BiLSTM model probability of FAKE
            fused_prob (float): Fused probability
            final_label (str): Final prediction label
        """
        plt.figure(figsize=(10, 6))
        
        # Create bars for each model and the fusion
        models = ['Swin Transformer', 'BiLSTM', 'Fusion']
        probs = [swin_prob, bilstm_prob, fused_prob]
        colors = ['#3498db', '#e74c3c', '#2ecc71']
        
        # Plot bars
        bars = plt.bar(models, probs, color=colors, alpha=0.7)
        
        # Add a horizontal line at 0.5 (threshold)
        plt.axhline(y=0.5, color='gray', linestyle='--', alpha=0.5)
        
        # Add labels and title
        plt.xlabel('Models')
        plt.ylabel('Probability of being FAKE')
        plt.title(f'Deepfake Detection Fusion Results: {final_label}')
        
        # Add text above bars
        for bar, prob in zip(bars, probs):
            plt.text(bar.get_x() + bar.get_width()/2., 
                    prob + 0.02, 
                    f'{prob:.4f}', 
                    ha='center')
        
        # Add weight labels
        plt.text(0, swin_prob - 0.07, f'Weight: {self.swin_weight}', ha='center')
        plt.text(1, bilstm_prob - 0.07, f'Weight: {self.bilstm_weight}', ha='center')
        
        # Set y-axis limits
        plt.ylim(0, 1.1)
        
        # Add a legend for the threshold
        plt.plot([], [], color='gray', linestyle='--', label='0.5 Threshold')
        plt.legend()
        
        plt.tight_layout()
        #plt.show()
        plt.savefig(f'{self.output_dir}/fusion_result.png')
    
    def cleanup(self):
        """Clean up temporary files"""
        import shutil
        try:
            if os.path.exists(self.output_dir):
                shutil.rmtree(self.output_dir)
                print(f"Cleaned up temporary directory: {self.output_dir}")
        except Exception as e:
            print(f"Error cleaning up: {e}")


def main():
    # Initialize the fusion detector
    detector = DeepfakeFusionDetector(bilstm_weight=0.8, swin_weight=0.2)
    
    # Specify the video path
    video_path = 'F:/Dataset/Custom Videos/FAKE/trump_elon_fake.mp4'
    
    try:
        # Run prediction
        final_label, fused_prob, final_confidence = detector.predict(video_path)
        
        # Clean up temporary files
        detector.cleanup()
        
    except Exception as e:
        print(f"Error in fusion pipeline: {e}")
        detector.cleanup()
'''
if __name__ == "__main__":
    main() '''